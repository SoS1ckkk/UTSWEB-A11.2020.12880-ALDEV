<?php
// Koneksi ke database
$servername = "localhost";
$username = "root"; // Ganti dengan username database Anda
$password = ""; // Ganti dengan password database Anda
$dbname = "poliklinik"; // Ganti dengan nama database Anda

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Mengambil data dari form
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$no_hp = $_POST['no_hp'];

// Menyiapkan dan mengeksekusi query untuk menyimpan data ke dalam tabel dokter
$sql = "INSERT INTO dokter (nama, alamat, no_hp)
        VALUES ('$nama', '$alamat', '$no_hp')";

if ($conn->query($sql) === TRUE) {
    // Jika data dokter berhasil disimpan, arahkan kembali ke halaman data master
    header("Location: datamaster.php");
    exit();
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Menutup koneksi
$conn->close();
?>
